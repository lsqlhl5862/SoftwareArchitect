package Lab2.Flyweight;

public abstract class CharImage {
    protected String intrinsicState;
    public abstract void display();
}
